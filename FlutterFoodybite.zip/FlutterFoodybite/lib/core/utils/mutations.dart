class Mutations {
  static String getfoods = ''' 
  query{
  allProducts{
    id
    name
    price
    image
    description
    category
  }
}
  ''';

  static String addItemToOrder = r'''
    mutation addOrder($price : Float!, $itemId:String!){
		createOrder(data : {price:$price, itemId: $itemId}){
    itemId
  }
}
''';
}

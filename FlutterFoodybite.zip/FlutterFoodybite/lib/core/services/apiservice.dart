abstract class APIService {
  void logSomething();
}

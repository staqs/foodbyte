import 'dart:ui';

class Category {
  final String name;
  final Color color1;
  final Color color2;
  final String img;
  final String value;

  Category({this.name, this.color1, this.color2, this.img, this.value});
}

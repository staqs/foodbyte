class Order {
  final String id;
  final double price;
  final String foodId;
  final String userId;
  final int quantity;
  Order({this.quantity, this.id, this.price, this.foodId, this.userId});
}

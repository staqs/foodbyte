List friends = [
  "assets/cm1.jpeg",
  "assets/cm2.jpeg",
  "assets/cm3.jpeg",
  "assets/cm4.jpeg",
  "assets/cm1.jpeg",
  "assets/cm2.jpeg",
  "assets/cm3.jpeg",
  "assets/cm4.jpeg",
  "assets/cm1.jpeg"
];
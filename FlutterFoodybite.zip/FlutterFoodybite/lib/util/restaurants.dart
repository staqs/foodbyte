List restaurants = [
  {
    "img": "assets/food1.jpeg",
    "title": "Happy Jones",
    "address": "12.00",
    "rating": "4.5"
  },
  {
    "img": "assets/food2.jpeg",
    "title": "Uncle Boons",
    "address": "32.00",
    "rating": "4.5"
  },
  {
    "img": "assets/food3.jpeg",
    "title": "Happy Jones",
    "address": "16.50",
    "rating": "4.5"
  },
  {
    "img": "assets/food4.jpeg",
    "title": "Uncle Boons",
    "address": "110",
    "rating": "4.5"
  },
  {
    "img": "assets/food5.jpeg",
    "title": "Happy Jones",
    "address": "62.00",
    "rating": "4.5"
  },
  {
    "img": "assets/food6.jpeg",
    "title": "Happy Jones",
    "address": "90.00",
    "rating": "4.5"
  },
  {
    "img": "assets/food7.jpeg",
    "title": "Happy Jones",
    "address": "45.00",
    "rating": "4.5"
  },
  {
    "img": "assets/food8.jpeg",
    "title": "Happy Jones",
    "address": "123.0",
    "rating": "4.5"
  },
  {
    "img": "assets/food9.jpeg",
    "title": "Happy Jones",
    "address": "121.00",
    "rating": "4.5"
  }
];